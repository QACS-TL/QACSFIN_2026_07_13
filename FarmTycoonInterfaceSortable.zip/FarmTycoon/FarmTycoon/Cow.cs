﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FarmTycoon
{
    public class Cow : Animal
    {
        public Cow(string name = "Ermintrude", string colour = "Brown", int hornlength = 10) : base(name, colour, 4)
        {
            HornLength = hornlength;
        }

        public int HornLength { get; set; }

        public string Moo()
        {
            return "Moo!";
        }

        public override string Eat(string food)
        {
            return $"{base.Eat(food)}. Actually, I'm a {Colour} COW ruminating on {food} ";
        }

        public override string Move(string direction)
        {
            EnergyLevel = EnergyLevel - 2;
            return $"I am a {Colour} cow called {Name} meandering on my {LimbCount} limbs to move {direction}.";
        }
    }
}
