﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FarmTycoon
{
    public abstract class AbstractAnimal
    {
        public abstract string Name { get; set; }
        public abstract string Colour { get; set; }
        public abstract int LimbCount { get; set; }

        public abstract string Move(string direction);

        public abstract string Eat(string food);

    }

    public interface IAnimal:IComparable<IAnimal>
    {
        string Name { get; set; }
        string Colour { get; set; }
        int LimbCount { get; set; }

        string Move(string direction);

        string Eat(string food);
    }
}
