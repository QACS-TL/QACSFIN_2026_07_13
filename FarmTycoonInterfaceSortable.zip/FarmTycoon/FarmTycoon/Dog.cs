﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FarmTycoon
{
    public class Dog 
    {
        public string Name { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string Colour { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public int LimbCount { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public string Eat(string food)
        {
            throw new NotImplementedException();
        }

        public string Move(string direction)
        {
            throw new NotImplementedException();
        }
    }
}
