﻿using FarmTycoon;

namespace FarmTycoonTests
{
    public class AnimalTests
    {
        [Fact]
        public void TestBasicCreation()
        {
            Animal animal = new Cow();

            Assert.Equal("Ermintrude", animal.Name);
            Assert.Equal("Brown", animal.Colour);
            Assert.Equal(4, animal.LimbCount);
            Assert.Equal(50, animal.EnergyLevel);
        }

        [Fact]
        public void TestChickenMotion()
        {
            //Arrange
            Animal animal = new Chicken();

            //Act
            string message = animal.Move("forward");

            //Assert
            Assert.Equal("I am a White chicken called Clucky. I have 2 limbs and I am flapping my wings to move forward.", message);
            Assert.Equal(49, animal.EnergyLevel);
        }
    }
}
