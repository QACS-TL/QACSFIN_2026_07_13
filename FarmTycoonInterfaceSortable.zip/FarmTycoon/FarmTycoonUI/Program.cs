﻿using FarmTycoon;

Cow animal1 = new Cow("Messi", "Blue and White", 14) { LimbCount = 5};
Chicken animal2 = new Chicken("Kane", "White", 22) { LimbCount = 2 };

Cow cow = new Cow(name:"Bessie", colour:"Purple", hornlength:15) { LimbCount = 1};
Chicken chicken = new Chicken(name: "HennyPenny", colour: "Red", wingSpan: 25) { LimbCount = 3 };



Console.WriteLine(cow.Moo());
Console.WriteLine(cow.Eat("Grass"));
//Console.WriteLine(chicken.Cluck());
Console.WriteLine(chicken.Eat("Corn"));

Console.WriteLine(animal1.Move("forward"));
Console.WriteLine(animal2.Move("up"));

Console.WriteLine(animal1.Eat("Smarties"));
Console.WriteLine(animal2.Eat("Grass"));

Console.WriteLine($"Animal 1 Energy Level: {animal1.EnergyLevel}");
Console.WriteLine($"Animal 2 Energy Level: {animal2.EnergyLevel}");

List<IAnimal> animalList = new List<IAnimal>();
animalList.Add(animal1);
animalList.Add(animal2);
animalList.Add(cow);
animalList.Add(chicken);
//animalList.Add(new Dog());

foreach(Animal animal in animalList)
{
    Console.WriteLine(animal.Eat("Cheese"));

    if (animal is Cow cowanimal)
    {
        Console.WriteLine(cowanimal.Moo());
    }
    else if (animal is Chicken chickenanimal)
    {
        Console.WriteLine(chickenanimal.Cluck());
    }
    Console.Write(animal.Move("in a circle"));

    Console.WriteLine($"Animal Name: {animal.Name}, Colour: {animal.Colour}, Limb Count: {animal.LimbCount}, Energy Level: {animal.EnergyLevel}, Food Eaten: {string.Join(", ", animal.foodEaten)}");
}

Console.WriteLine("***************************************");
animalList.ForEach(a => Console.WriteLine(a));

animalList.Sort();

Console.WriteLine("***************************************");
animalList.ForEach(a => Console.WriteLine(a));


