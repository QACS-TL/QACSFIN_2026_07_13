﻿namespace BankAccounts
{
    public class CurrentAccount : Account
    {
        public decimal OverdraftLimit { get; set; }

        public CurrentAccount(
            string name = "Anonymous",
            string id = "00000000",
            decimal balance = 0,
            decimal overdraftLimit = 0)
            : base(name, id, balance)
        {
            OverdraftLimit = overdraftLimit;
        }

        public override decimal Debit(decimal amount)
        {
            if (amount <= 0)
                return balance;

            if (balance - amount < -OverdraftLimit)
                return balance;

            return balance -= amount;
        }
    }
}