﻿namespace BankAccounts
{
    public class SavingsAccount : Account
    {
        public decimal InterestRate { get; set; }

        public SavingsAccount(
            string name = "Anonymous",
            string id = "00000000",
            decimal balance = 0,
            decimal interestRate = 0)
            : base(name, id, balance)
        {
            InterestRate = interestRate;
        }

        public virtual void ApplyInterest()
        {
            balance += balance * (InterestRate / 100m);
        }
    }
}