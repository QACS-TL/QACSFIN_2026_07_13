﻿using System.Runtime.CompilerServices;

namespace BankAccounts
{
    public  class Account
    {
        static Account()
        {
            AccountCount = 0;
               
        }

        public Account(string name = "Anonymous", string id = "00000000", decimal balance = 0)
        {
            Name = name;
            ID = id;
            Balance = balance;
            AccountCount++;
        }

        public static int AccountCount { get; private set; } 

        //public Account(string name, decimal balance) : this(name, "00000000", balance)
        //{

        //}

        //public Account()
        //{
        //    Name = "Anonymous";
        //    ID = "00000000";
        //    Balance = 0;
        //}

        private string name = "Anonymous";

        public string Name
        {
            get { return name; }
            set
            {
                if (string.IsNullOrWhiteSpace(value) || value.Length < 3)
                    return;
                name = value;
            }
        }

        private string id = "00000000";

        public string ID
        {
            get { return id; }
            set
            {
                if (value.Length != 8 || !value.All(char.IsDigit))
                {
                    return;
                }
                id = value;
            }
        }

        protected decimal balance;
        private bool disposedValue;

        public decimal Balance
        {
            get { return balance; }
            set
            {
                if (value < 0)
                {
                    value = 0;
                }
                balance = value;
            }
        }

        public static string DoSomething()
        {
            return $"There are {AccountCount} accounts.";
        }

        public virtual decimal Credit(decimal amount) {
            if (amount <= 0)
                return this.balance;
            return this.balance += amount;
        }

        public virtual decimal Debit(decimal amount) {
            if (amount <= 0)
                return balance;
            if (amount > balance)
            {
                return balance;
            }
            return balance -= amount;
        }

        public void Transfer(Account account, decimal amount)
        {
            decimal currentBalance = this.balance;
            this.Debit(amount);
            if (currentBalance != this.balance)
                account.Credit(amount);
        }

        public Account Clone()
        {
            Account account = new();
            account.Balance = this.balance;
            account.Name = this.name;
            account.ID = this.id;
            return account; 
        }
    }
}
