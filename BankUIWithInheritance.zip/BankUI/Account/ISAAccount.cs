﻿namespace BankAccounts
{
    public class ISAAccount : SavingsAccount
    {
        public const decimal MaxBalance = 20000m;

        public ISAAccount(
            string name = "Anonymous",
            string id = "00000000",
            decimal balance = 0,
            decimal interestRate = 0)
            : base(name, id, balance, interestRate)
        {
        }

        public override decimal Credit(decimal amount)
        {
            if (amount <= 0)
                return balance;

            if (balance + amount > MaxBalance)
                return balance;

            return balance += amount;
        }

        public override void ApplyInterest()
        {
            // Allow interest to grow beyond £20,000
            base.ApplyInterest();
        }
    }
}
