﻿using BankAccounts;
using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccountsTests
{
    public class SavingsAccountTests
    {
        [Theory]
        [InlineData(1000, 5, 1050)]
        [InlineData(5000, 2.5, 5125)]
        [InlineData(100, 10, 110)]
        public void ApplyInterest_AddsInterestToBalance(
            decimal startingBalance,
            decimal interestRate,
            decimal expectedBalance)
        {
            // Arrange
            SavingsAccount account = new(
                balance: startingBalance,
                interestRate: interestRate);

            // Act
            account.ApplyInterest();

            // Assert
            Assert.Equal(expectedBalance, account.Balance);
        }
    }
}
