﻿using BankAccounts;
using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccountsTests
{
    public class ISAAccountTests
    {
        [Theory]
        [InlineData(19000, 500, 19500)]
        [InlineData(19500, 500, 20000)]
        [InlineData(19500, 1000, 19500)] // exceeds limit
        [InlineData(20000, 1, 20000)]    // already at limit
        public void Credit_CannotExceedMaximumBalance(
            decimal startingBalance,
            decimal creditAmount,
            decimal expectedBalance)
        {
            // Arrange
            ISAAccount account = new(
                balance: startingBalance,
                interestRate: 5);

            // Act
            account.Credit(creditAmount);

            // Assert
            Assert.Equal(expectedBalance, account.Balance);
        }


        [Theory]
        [InlineData(19000, 5, 19950)]
        [InlineData(19900, 5, 20895)]
        [InlineData(20000, 5, 21000)]
        [InlineData(25000, 3, 25750)]
        public void ApplyInterest_CanIncreaseBalanceBeyondLimit(
           decimal startingBalance,
           decimal interestRate,
           decimal expectedBalance)
        {
            // Arrange
            ISAAccount account = new(
                balance: startingBalance,
                interestRate: interestRate);

            // Act
            account.ApplyInterest();

            // Assert
            Assert.Equal(expectedBalance, account.Balance);
        }
    }
}
