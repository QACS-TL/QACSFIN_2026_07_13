﻿using BankAccounts;

namespace AccountTests
{
    public class BankAccountTests
    {
        [Fact]
        public void Credit_PositiveAmount_IncreasesBalance()
        {
            // Arrange
            var account = new Account();
            account.Balance = 100m;

            // Act
            var result = account.Credit(50m);

            // Assert
            Assert.Equal(150m, result);
            Assert.Equal(150m, account.Balance);
        }

        [Fact]
        public void Credit_ZeroAmount_DoesNotChangeBalance()
        {
            // Arrange
            var account = new Account();
            account.Balance = 100m;

            // Act
            var result = account.Credit(0m);

            // Assert
            Assert.Equal(100m, result);
            Assert.Equal(100m, account.Balance);
        }

        [Fact]
        public void Credit_NegativeAmount_DoesNotChangeBalance()
        {
            // Arrange
            var account = new Account();
            account.Balance = 100m;

            // Act
            var result = account.Credit(-50m);

            // Assert
            Assert.Equal(100m, result);
            Assert.Equal(100m, account.Balance);
        }

        [Fact]
        public void Debit_ValidAmount_DecreasesBalance()
        {
            // Arrange
            var account = new Account();
            account.Balance = 100m;

            // Act
            var result = account.Debit(40m);

            // Assert
            Assert.Equal(60m, result);
            Assert.Equal(60m, account.Balance);
        }

        [Fact]
        public void Debit_ZeroAmount_DoesNotChangeBalance()
        {
            // Arrange
            var account = new Account();
            account.Balance = 100m;

            // Act
            var result = account.Debit(0m);

            // Assert
            Assert.Equal(100m, result);
            Assert.Equal(100m, account.Balance);
        }

        [Fact]
        public void Debit_NegativeAmount_DoesNotChangeBalance()
        {
            // Arrange
            var account = new Account();
            account.Balance = 100m;

            // Act
            var result = account.Debit(-25m);

            // Assert
            Assert.Equal(100m, result);
            Assert.Equal(100m, account.Balance);
        }

        [Fact]
        public void Debit_AmountGreaterThanBalance_DoesNotChangeBalance()
        {
            // Arrange
            var account = new Account();
            account.Balance = 100m;

            // Act
            var result = account.Debit(150m);

            // Assert
            Assert.Equal(100m, result);
            Assert.Equal(100m, account.Balance);
        }

        [Fact]
        public void Debit_AmountEqualToBalance_ResultsInZeroBalance()
        {
            // Arrange
            var account = new Account();
            account.Balance = 100m;

            // Act
            var result = account.Debit(100m);

            // Assert
            Assert.Equal(0m, result);
            Assert.Equal(0m, account.Balance);
        }

        [Fact]
        public void Transfer_ValidAmount_MovesMoneyBetweenAccounts()
        {
            // Arrange
            var source = new Account();
            source.Balance = 100m;

            var destination = new Account();
            destination.Balance = 50m;

            // Act
            source.Transfer(destination, 25m);

            // Assert
            Assert.Equal(75m, source.Balance);
            Assert.Equal(75m, destination.Balance);
        }

        [Fact]
        public void Transfer_AmountGreaterThanSourceBalance_DestinationAndSourceUnchanged()
        {
            // Arrange
            var source = new Account();
            source.Balance = 100m;

            var destination = new Account();
            destination.Balance = 50m;

            // Act
            source.Transfer(destination, 150m);

            // Assert
            Assert.Equal(100m, source.Balance);
            Assert.Equal(50m, destination.Balance);
        }

        [Fact]
        public void Transfer_NegativeAmount_DoesNotChangeEitherAccount()
        {
            // Arrange
            var source = new Account();
            source.Balance = 100m;

            var destination = new Account();
            destination.Balance = 50m;

            // Act
            source.Transfer(destination, -10m);

            // Assert
            Assert.Equal(100m, source.Balance);
            Assert.Equal(50m, destination.Balance);
        }

        [Fact]
        public void Account_DefaultValues_AreCorrect()
        {
            // Arrange & Act
            var account = new Account();

            // Assert
            Assert.Equal("Anonymous", account.Name);
            Assert.Equal("00000000", account.ID);
            Assert.Equal(0.0m, account.Balance);
        }


        [Theory]
        [InlineData("12345678", "12345678")]
        [InlineData("A1234567", "00000000")]
        [InlineData("1234567", "00000000")]
        [InlineData("A123456", "00000000")]
        public void Account_ID_Tests(string  id, string expected_id)
        {
            // Arrange
            var account = new Account();

            //Act
            account.ID = id;

            // Assert
            Assert.Equal(expected_id, account.ID);
        }


        [Theory]
        [InlineData("Messi", "Messi")]
        [InlineData("Ian", "Ian")]
        [InlineData("", "Anonymous")]
        [InlineData("A", "Anonymous")]
        [InlineData("AB", "Anonymous")]
        public void Account_Name_Tests(string name, string expected_name)
        {
            // Arrange
            var account = new Account();

            //Act
            account.Name = name;

            // Assert
            Assert.Equal(expected_name, account.Name);
        }
    
    
        [Theory]
        [InlineData(1000.00, 1000.00)]
        [InlineData(1, 1)]
        [InlineData(0.01, 0.01)]
        [InlineData(0, 0)]
        [InlineData(-1.00, 0.00)]
        [InlineData(-0.01, 0.00)]
        public void Account_Balance_Tests(decimal balance, decimal expected_balance)
        {
            // Arrange
            var account = new Account();

            //Act
            account.Balance = balance;

            // Assert
            Assert.Equal(expected_balance, account.Balance);
        }
    }
}
