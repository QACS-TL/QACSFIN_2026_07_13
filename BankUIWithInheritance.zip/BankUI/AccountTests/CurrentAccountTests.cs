﻿using BankAccounts;
using Xunit;

namespace BankAccountsTests
{
    public class CurrentAccountTests
    {
        [Theory]
        [InlineData(1000, 500, 1200, -200)]
        [InlineData(1000, 500, 1500, -500)]
        [InlineData(1000, 500, 1600, 1000)] // exceeds overdraft, no change
        public void Debit_UsesOverdraftLimit(
            decimal startingBalance,
            decimal overdraftLimit,
            decimal withdrawalAmount,
            decimal expectedBalance)
        {
            // Arrange
            CurrentAccount account = new(
                balance: startingBalance,
                overdraftLimit: overdraftLimit);

            // Act
            account.Debit(withdrawalAmount);

            // Assert
            Assert.Equal(expectedBalance, account.Balance);
        }
    }
    
}