﻿using FarmTycoon;

namespace FarmTycoonTests
{
    public class AnimalTests
    {
        [Fact]
        public void TestBasicCreation()
        {
            Animal animal = new Animal();

            Assert.Equal("Anonymous", animal.name);
            Assert.Equal("Black", animal.colour);
            Assert.Equal(4, animal.limbCount);
            Assert.Equal(50, animal.energyLevel);
        }

        [Fact]
        public void TestAnimalMotion()
        {
            //Arrange
            Animal animal = new Animal();

            //Act
            string message = animal.Move("forward");

            //Assert
            Assert.Equal("I am a Black animal called Anonymous. I have 4 limbs and I am moving forward.", message);
            Assert.Equal(49, animal.energyLevel);
        }
    }
}
