﻿namespace FarmTycoon
{
    public class Animal
    {
        public string name = "Anonymous";
        public string colour = "Black";
        public int limbCount = 4;
        public int energyLevel = 50;
        public List<string> foodEaten = new List<string>();

        public string Move(string direction)
        {
            energyLevel--;
            return $"I am a {this.colour} animal called {name}. I have {limbCount} limbs and I am moving {direction}.";
        }

        public string Eat(string food)
        {
            energyLevel++;
            foodEaten.Add(food);
            return $"I am a {colour} animal called {name}. using my {limbCount} limbs to help me eat {food}.";
        }
    }
}
