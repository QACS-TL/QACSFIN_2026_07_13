﻿using FarmTycoon;

Animal animal1 = new Animal();
Animal animal2 = new Animal();

animal1.name = "Messi";
animal1.colour = "Blue and White";
animal1.limbCount = 5;

animal2.name = "Kane";
animal2.colour = "White";
animal2.limbCount = 2;

Console.WriteLine(animal1.Move("forward"));
Console.WriteLine(animal2.Move("up"));

Console.WriteLine(animal1.Eat("Smarties"));
Console.WriteLine(animal2.Eat("Grass"));

Console.WriteLine($"Animal 1 Energy Level: {animal1.energyLevel}");
Console.WriteLine($"Animal 2 Energy Level: {animal2.energyLevel}");

List<Animal> animalList = new List<Animal>();
animalList.Add(animal1);
animalList.Add(animal2);

foreach(Animal animal in animalList)
{
    animal.Eat("Cheese");
    Console.WriteLine($"Animal Name: {animal.name}, Colour: {animal.colour}, Limb Count: {animal.limbCount}, Energy Level: {animal.energyLevel}, Food Eaten: {string.Join(", ", animal.foodEaten)}");
}
