﻿using BankAccounts;
using System.Xml.Linq;

Account account1 = new Account("Irma Person", "12345678", 100.00m);
//account1.Name = "Irma Person";
//account1.ID = "12345678";
//account1.Balance = 100.00m;

Account account2 = new Account();
//{ 
//    Name= "John Doe",
//    ID = "87654321",
//    Balance = 200.00m
//};

Console.WriteLine($"There are now {Account.AccountCount} accounts in existance");

account1.Credit(50.0m);
account2.Debit(50.0m);

account1.Transfer(account2, 100.00M);

//account1.Transfer("88888888", 100.00M);

//Account.Transfer("12345678", "88888888", 100.00M);

Console.WriteLine(account1.Balance);
Console.WriteLine(account2.Balance);

List<Account> accounts = new List<Account>();
accounts.Add(account1);
accounts.Add(account2);
accounts.Add(new Account() { Name = "Hamza", ID = "44444444", Balance = 150.00m });
accounts.Add(new Account() { Name = "Zoe", ID = "55555555", Balance = 4.50m });

// Apply Interest or determine Overdraft Limit
foreach (Account a in accounts)
{
    Console.WriteLine($"Account Name:{a.Name}, Number: {a.ID}, Balance: {a.Balance}");
}






