﻿using System.Runtime.CompilerServices;

namespace BankAccounts
{
    public class Account
    {
        public Account(string name="Anonymous", string id="00000000", decimal balance=0)
        {
            Name = name;
            ID = id;
            Balance = balance;
            AccountCount++;
        }

        public static int AccountCount { get; private set; } = 0;

        //public Account(string name,  decimal balance):this(name, "00000000", balance)
        //{

        //}

        //public Account()
        //{
        //    Name = "Anonymous";
        //    ID = "00000000";
        //    Balance = 0;
        //}

        private string name;

        public string Name
        {
            get { return name; }
            set
            {
                if (value.Length <= 2)
                {
                    return;
                }
                name = value;
            }
        }

        private string id;

        public string ID
        {
            get { return id; }
            set
            {
                if (value.Length != 8 || !value.All(char.IsDigit))
                {
                    return;
                }
                id = value;
            }
        }

        protected decimal balance;
        private bool disposedValue;

        public decimal Balance
        {
            get { return balance; }
            set
            {
                if (value < 0)
                {
                    value = 0;
                }
                balance = value;
            }
        }

        public decimal Credit(decimal amount) {
            if (amount <= 0)
                return balance;
            return balance += amount;
        }

        public decimal Debit(decimal amount) {
            if (amount <= 0)
                return balance;
            if (amount > balance)
            {
                return balance;
            }
            return balance -= amount;
        }

        public void Transfer(Account account, decimal amount)
        {
            decimal currentBalance = this.balance;
            this.Debit(amount);
            if (currentBalance != this.balance)
                account.Credit(amount);
        }
    }
}
