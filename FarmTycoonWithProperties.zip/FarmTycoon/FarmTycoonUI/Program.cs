﻿using FarmTycoon;

Animal animal1 = new Animal();
Animal animal2 = new Animal();

animal1.Name = "Messi";
animal1.Colour = "Blue and White";
animal1.LimbCount = -1;

animal2.Name = "Kane";
animal2.Colour = "White";
animal2.LimbCount = 2;

Console.WriteLine(animal1.Move("forward"));
Console.WriteLine(animal2.Move("up"));

Console.WriteLine(animal1.Eat("Smarties"));
Console.WriteLine(animal2.Eat("Grass"));

Console.WriteLine($"Animal 1 Energy Level: {animal1.EnergyLevel}");
Console.WriteLine($"Animal 2 Energy Level: {animal2.EnergyLevel}");

List<Animal> animalList = new List<Animal>();
animalList.Add(animal1);
animalList.Add(animal2);

foreach(Animal animal in animalList)
{
    animal.Eat("Cheese");
    Console.WriteLine($"Animal Name: {animal.Name}, Colour: {animal.Colour}, Limb Count: {animal.LimbCount}, Energy Level: {animal.EnergyLevel}, Food Eaten: {string.Join(", ", animal.foodEaten)}");
}


