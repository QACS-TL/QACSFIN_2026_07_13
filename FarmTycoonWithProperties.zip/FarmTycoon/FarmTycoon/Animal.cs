﻿namespace FarmTycoon
{
    public class Animal
    {
        List<string> colours = new() { "Black", "White", "Red", "Blue and White", "Purple" };
        public string Name { get; set; } = "";
        private string colour = "Black";
        private int limbCount = 4;
        private int energyLevel = 50;
        public List<string> foodEaten = new List<string>();

        // The Java Way...
        //public int GetLimbCount()
        //{
        //    return limbCount;
        //}

        //public void SetLimbCount(int value)
        //{
        //    if (value < 0)
        //    {
        //        value = 0;
        //    }
        //    limbCount = value;
        //}

        // The C# Way...
        public int LimbCount
        {
            get {
                return limbCount;
            }
            set
            {
                if (value < 0)
                {
                    value = 0;
                }
                limbCount = value;
            }
        }

        public string Colour
        {
            get
            {
                return colour;
            }
            set
            {
                if (colours.Contains(value))
                {
                    colour = value;
                }
                else
                {
                    colour = "Black";
                }
            }
        }

        public int EnergyLevel
        {
            get
            {
                return energyLevel; 
            } 
        }

        public string Move(string direction)
        {
            energyLevel--;
            return $"I am a {this.colour} animal called {Name}. I have {limbCount} limbs and I am moving {direction}.";
        }

        public string Eat(string food)
        {
            energyLevel++;
            foodEaten.Add(food);
            return $"I am a {colour} animal called {name}. using my {limbCount} limbs to help me eat {food}.";
        }
    }
}
