﻿using FarmTycoon;

namespace FarmTycoonTests
{
    public class AnimalTests
    {
        [Fact]
        public void TestBasicCreation()
        {
            Animal animal = new Animal();

            Assert.Equal("Anonymous", animal.Name);
            Assert.Equal("Black", animal.Colour);
            Assert.Equal(4, animal.LimbCount);
            Assert.Equal(50, animal.EnergyLevel);
        }

        [Fact]
        public void TestAnimalMotion()
        {
            //Arrange
            Animal animal = new Animal();

            //Act
            string message = animal.Move("forward");

            //Assert
            Assert.Equal("I am a Black animal called Anonymous. I have 4 limbs and I am moving forward.", message);
            Assert.Equal(49, animal.EnergyLevel);
        }
    }
}
