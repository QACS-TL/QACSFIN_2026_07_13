﻿using FarmTycoon;

Animal animal1 = new Animal("Messi", "Blue and White", 4);
Animal animal2 = new Animal("Kane", "White", 2);

Cow cow = new Cow(name:"Bessie", colour:"Purple", hornlength:15);
Chicken chicken = new Chicken(name: "HennyPenny", colour: "Red", wingSpan: 25);



Console.WriteLine(cow.Moo());
Console.WriteLine(cow.Eat("Grass"));
//Console.WriteLine(chicken.Cluck());
Console.WriteLine(chicken.Eat("Corn"));

Console.WriteLine(animal1.Move("forward"));
Console.WriteLine(animal2.Move("up"));

Console.WriteLine(animal1.Eat("Smarties"));
Console.WriteLine(animal2.Eat("Grass"));

Console.WriteLine($"Animal 1 Energy Level: {animal1.EnergyLevel}");
Console.WriteLine($"Animal 2 Energy Level: {animal2.EnergyLevel}");

List<Animal> animalList = new List<Animal>();
animalList.Add(animal1);
animalList.Add(animal2);
animalList.Add(cow);
animalList.Add(chicken);

foreach(Animal animal in animalList)
{
    Console.WriteLine(animal.Eat("Cheese"));

    if (animal is Cow cowanimal)
    {
        Console.WriteLine(cowanimal.Moo());
    }
    else if (animal is Chicken chickenanimal)
    {
        Console.WriteLine(chickenanimal.Cluck());
    }

    Console.WriteLine($"Animal Name: {animal.Name}, Colour: {animal.Colour}, Limb Count: {animal.LimbCount}, Energy Level: {animal.EnergyLevel}, Food Eaten: {string.Join(", ", animal.foodEaten)}");
}


