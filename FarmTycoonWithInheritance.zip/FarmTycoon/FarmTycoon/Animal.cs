﻿namespace FarmTycoon
{
    public class Animal
    {
        public Animal(string name, string colour = "Black", int limbCount = 4)
        {
            Name = name;
            Colour = colour;
            LimbCount = limbCount;
            energyLevel = 50;
        }

        List<string> colours = new() { "Black", "White", "Red", "Brown", "Blue and White", "Purple" };
        public string Name { get; set; }
        private string colour;
        private int limbCount;
        private int energyLevel;
        public List<string> foodEaten = new List<string>();

        // The Java Way...
        //public int GetLimbCount()
        //{
        //    return limbCount;
        //}

        //public void SetLimbCount(int value)
        //{
        //    if (value < 0)
        //    {
        //        value = 0;
        //    }
        //    limbCount = value;
        //}

        // The C# Way...
        public int LimbCount
        {
            get {
                return limbCount;
            }
            set
            {
                if (value < 0)
                {
                    value = 0;
                }
                limbCount = value;
            }
        }

        public string Colour
        {
            get
            {
                return colour;
            }
            set
            {
                if (colours.Contains(value))
                {
                    colour = value;
                }
                else
                {
                    colour = "Black";
                }
            }
        }

        public int EnergyLevel
        {
            get
            {
                return energyLevel; 
            } 
        }

        public string Move(string direction)
        {
            energyLevel--;
            return $"I am a {this.colour} animal called {Name}. I have {limbCount} limbs and I am moving {direction}.";
        }

        public virtual string Eat(string food)
        {
            energyLevel++;
            foodEaten.Add(food);
            return $"I am a {colour} animal called {Name}. using my {limbCount} limbs to help me eat {food}.";
        }
    }
}
