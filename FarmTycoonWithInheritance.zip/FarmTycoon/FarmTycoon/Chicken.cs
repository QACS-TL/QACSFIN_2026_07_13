﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FarmTycoon
{
    public class Chicken : Animal
    {
        public Chicken(string name = "Clucky", string colour = "White", int wingSpan = 20) : base(name, colour, 2)
        {
            WingSpan = wingSpan;
        }

        public int WingSpan { get; set; }

        public string Cluck()
        {
            return "Cluck!";
        }

        public override string Eat(string food)
        {
            return $"I'm a {Colour} CHICKEN using my beak to peck on {food} ";
        }
    }
}
