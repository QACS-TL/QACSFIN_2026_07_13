﻿using EntityFrameworkFun.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client.Utils;
using System.Data;
using System.Diagnostics;


namespace MyNamespace
{
    public class Program
    {
        public static void Main()
        {
            var stopwatch = Stopwatch.StartNew();
            NorthwindContext context = new NorthwindContext();

            IEnumerable<Customer> customers = context.Customers;
            foreach (Customer cust in customers)
            {
                Console.WriteLine($"Company Name: {cust.CompanyName}, Contact Name: {cust.ContactName}");
            }
            stopwatch.Stop();
            Console.WriteLine($"Elapsed: {stopwatch.ElapsedMilliseconds} ms");
            Console.WriteLine($"Elapsed: {stopwatch.Elapsed.TotalSeconds:F3} seconds");

            Console.WriteLine("************************");

            stopwatch = Stopwatch.StartNew();
            Customer customer = context.Customers.FirstOrDefault(c => c.CustomerId == "ALFKI");
            customer.ContactName += "*";
            context.SaveChanges();
            stopwatch.Stop();
            Console.WriteLine($"Elapsed: {stopwatch.ElapsedMilliseconds} ms");
            Console.WriteLine($"Elapsed: {stopwatch.Elapsed.TotalSeconds:F3} seconds");

            Console.WriteLine("************************");

            stopwatch = Stopwatch.StartNew();

            SqlConnection con = new SqlConnection()
            {
                ConnectionString = "Server=(local);Database=Northwind;trusted_Connection=true;Encrypt=False;"
            };
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Customers";

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Customer c = new Customer
                {
                    CustomerId = reader["CustomerID"].ToString(),
                    CompanyName = reader["CompanyName"].ToString(),
                    ContactName = reader["ContactName"].ToString(),
                    ContactTitle = reader["ContactTitle"].ToString(),
                    Address = reader["Address"].ToString(),
                    City = reader["City"].ToString(),
                    Region = reader["Region"].ToString(),
                    PostalCode = reader["PostalCode"].ToString(),
                    Country = reader["Country"].ToString(),
                    Phone = reader["Phone"].ToString(),
                    Fax = reader["Fax"].ToString()
                };
                Console.WriteLine($"Company Name: {c.CompanyName}, Contact Name: {c.ContactName}");
            }

            con.Close();
            stopwatch.Stop();
            Console.WriteLine($"Elapsed: {stopwatch.ElapsedMilliseconds} ms");
            Console.WriteLine($"Elapsed: {stopwatch.Elapsed.TotalSeconds:F3} seconds");

            Console.WriteLine("************************");

            //Stored Proc using ADO.NET
            stopwatch = Stopwatch.StartNew();
            con.Open();
            cmd = con.CreateCommand();
            cmd.CommandText = "CustOrderHist";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CustomerID", "ALFKI");
            reader = cmd.ExecuteReader();

            while (reader.Read())
            {
            Console.WriteLine($"{reader["ProductName"]} - {reader["Total"]}");
            }
            con.Close();
            stopwatch.Stop();
            Console.WriteLine($"Elapsed: {stopwatch.ElapsedMilliseconds} ms");
            Console.WriteLine($"Elapsed: {stopwatch.Elapsed.TotalSeconds:F3} seconds");

            Console.WriteLine("************************");

            //Stored Proc using Entity Framework
            stopwatch = Stopwatch.StartNew();
            var customerId = "ALFKI";

            var results = context.Set<CustOrderHistResult>()
                .FromSqlRaw($"EXEC CustOrderHist @CustomerID = {customerId}")
                .ToList();

            foreach (var item in results)
            {
                Console.WriteLine($"{item.ProductName} - {item.Total}");
            }
            stopwatch.Stop();
            Console.WriteLine($"Elapsed: {stopwatch.ElapsedMilliseconds} ms");
            Console.WriteLine($"Elapsed: {stopwatch.Elapsed.TotalSeconds:F3} seconds");


        }
    }
}
