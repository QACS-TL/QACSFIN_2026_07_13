﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntityFrameworkFun.Models
{
    public class CustOrderHistResult
    {
        public string ProductName { get; set; }
        public int Total { get; set; }
    }
}
