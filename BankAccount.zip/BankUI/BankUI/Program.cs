﻿using BankAccounts;
using System.Xml.Linq;

Account account1 = new Account();
account1.name = "Irma Person";
account1.id = "123456";
account1.balance = 100.00m;

Account account2 = new Account() 
{ 
    name = "A. N. Other", 
    id = "888888", 
    balance =  400.00m 
};

account1.Credit(50.0m);
account2.Debit(50.0m);

account1.Transfer(account2, 100.00M);

//account1.Transfer("888888", 100.00M);

//Account.Transfer("123456", "888888", 100.00M);

Console.WriteLine(account1.balance);
Console.WriteLine(account2.balance);

List<Account> accounts = new List<Account>();
accounts.Add(account1);
accounts.Add(account2);
accounts.Add(new Account() { name = "Hamza", id = "444444", balance = 150.00m });
accounts.Add(new Account() { name = "Zoe", id = "555555", balance = 4.50m });

// Apply Interest or determine Overdraft Limit
foreach (Account a in accounts)
{
    Console.WriteLine($"Account Name:{a.name}, Number: {a.id}, Balance: {a.balance}");
}






