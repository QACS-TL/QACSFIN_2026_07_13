﻿using MathFun;

int result = Arithmetic.Add(3, 5);
Console.WriteLine(result);