﻿namespace MathFun
{
    public class Arithmetic
    {
        public static int Add(int a, int b)
        {
            return a + b;
        }

        public static int Subtract(int a, int b)
        {
            b = -b;
            return Add(a, b);
        }
    }
}
