﻿using MathFun;

namespace MathTests
{
    public class ArithmeticTests
    {
        [Fact]
        public void TestAddMethodWithTwoPositiveIntegers()
        {
            int result = Arithmetic.Add(3, 5);

            Assert.Equal(8, result);
        }

        [Fact]
        public void TestAddMethodWithTwoNegativeIntegers()
        {
            int result = Arithmetic.Add(-3, -5);

            Assert.Equal(-8, result);
        }


        [Fact]
        public void TestAddMethodWithTwozeros()
        {
            int result = Arithmetic.Add(0, 0);

            Assert.Equal(0, result);
        }



        [Theory]
        [InlineData(10, 6, 4)]
        [InlineData(-10, 6, -16)]
        [InlineData(-10, -6, -4)]
        [InlineData(10, -6, 16)]
        public void TestSubtractMethod(int a, int b, int expectedResult)
        {
            // Arrange

            //Act
            int result = Arithmetic.Subtract(a, b);

            //Assert
            Assert.Equal(expectedResult, result);
        }

    }
}
