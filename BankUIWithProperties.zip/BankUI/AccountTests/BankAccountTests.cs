﻿using BankAccounts;

namespace AccountTests
{
    public class BankAccountTests
    {
        [Fact]
        public void Credit_PositiveAmount_IncreasesBalance()
        {
            // Arrange
            var account = new Account();
            account.balance = 100m;

            // Act
            var result = account.Credit(50m);

            // Assert
            Assert.Equal(150m, result);
            Assert.Equal(150m, account.balance);
        }

        [Fact]
        public void Credit_ZeroAmount_DoesNotChangeBalance()
        {
            // Arrange
            var account = new Account();
            account.balance = 100m;

            // Act
            var result = account.Credit(0m);

            // Assert
            Assert.Equal(100m, result);
            Assert.Equal(100m, account.balance);
        }

        [Fact]
        public void Credit_NegativeAmount_DoesNotChangeBalance()
        {
            // Arrange
            var account = new Account();
            account.balance = 100m;

            // Act
            var result = account.Credit(-50m);

            // Assert
            Assert.Equal(100m, result);
            Assert.Equal(100m, account.balance);
        }

        [Fact]
        public void Debit_ValidAmount_DecreasesBalance()
        {
            // Arrange
            var account = new Account();
            account.balance = 100m;

            // Act
            var result = account.Debit(40m);

            // Assert
            Assert.Equal(60m, result);
            Assert.Equal(60m, account.balance);
        }

        [Fact]
        public void Debit_ZeroAmount_DoesNotChangeBalance()
        {
            // Arrange
            var account = new Account();
            account.balance = 100m;

            // Act
            var result = account.Debit(0m);

            // Assert
            Assert.Equal(100m, result);
            Assert.Equal(100m, account.balance);
        }

        [Fact]
        public void Debit_NegativeAmount_DoesNotChangeBalance()
        {
            // Arrange
            var account = new Account();
            account.balance = 100m;

            // Act
            var result = account.Debit(-25m);

            // Assert
            Assert.Equal(100m, result);
            Assert.Equal(100m, account.balance);
        }

        [Fact]
        public void Debit_AmountGreaterThanBalance_DoesNotChangeBalance()
        {
            // Arrange
            var account = new Account();
            account.balance = 100m;

            // Act
            var result = account.Debit(150m);

            // Assert
            Assert.Equal(100m, result);
            Assert.Equal(100m, account.balance);
        }

        [Fact]
        public void Debit_AmountEqualToBalance_ResultsInZeroBalance()
        {
            // Arrange
            var account = new Account();
            account.balance = 100m;

            // Act
            var result = account.Debit(100m);

            // Assert
            Assert.Equal(0m, result);
            Assert.Equal(0m, account.balance);
        }

        [Fact]
        public void Transfer_ValidAmount_MovesMoneyBetweenAccounts()
        {
            // Arrange
            var source = new Account();
            source.balance = 100m;

            var destination = new Account();
            destination.balance = 50m;

            // Act
            source.Transfer(destination, 25m);

            // Assert
            Assert.Equal(75m, source.balance);
            Assert.Equal(75m, destination.balance);
        }

        [Fact]
        public void Transfer_AmountGreaterThanSourceBalance_DestinationAndSourceUnchanged()
        {
            // Arrange
            var source = new Account();
            source.balance = 100m;

            var destination = new Account();
            destination.balance = 50m;

            // Act
            source.Transfer(destination, 150m);

            // Assert
            Assert.Equal(100m, source.balance);
            Assert.Equal(50m, destination.balance);
        }

        [Fact]
        public void Transfer_NegativeAmount_DoesNotChangeEitherAccount()
        {
            // Arrange
            var source = new Account();
            source.balance = 100m;

            var destination = new Account();
            destination.balance = 50m;

            // Act
            source.Transfer(destination, -10m);

            // Assert
            Assert.Equal(100m, source.balance);
            Assert.Equal(50m, destination.balance);
        }

        [Fact]
        public void Account_DefaultValues_AreCorrect()
        {
            // Arrange & Act
            var account = new Account();

            // Assert
            Assert.Equal("Anonymous", account.name);
            Assert.Equal("XXXXXX", account.id);
            Assert.Equal(0.0m, account.balance);
        }
    }
}
