﻿using System.Runtime.CompilerServices;

namespace BankAccounts
{
    public class Account
    {
        public string name = "Anonymous";
        public string id = "XXXXXX";
        public decimal balance = 0.0m;

        public decimal Credit(decimal amount) {
            if (amount <= 0)
                return balance;
            return balance += amount;
        }

        public decimal Debit(decimal amount) {
            if (amount <= 0)
                return balance;
            if (amount > balance)
            {
                return balance;
            }
            return balance -= amount;
        }

        public void Transfer(Account account, decimal amount)
        {
            decimal currentBalance = this.balance;
            this.Debit(amount);
            if (currentBalance != this.balance)
                account.Credit(amount);
        }
    }
}
